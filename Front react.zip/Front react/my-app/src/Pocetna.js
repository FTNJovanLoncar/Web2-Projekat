import { useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import './Pocetna.css';

const Pocetna = ({ user, setUser }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token"); // clear stored JWT
    setUser(null); // reset user state in App.js
    navigate("/"); // redirect back to home
  };

  return (
    <div className='pocetna-container'>
      {!user ? (
        <ul className='nav nav-pills nav-fill navigation-bar'>
          <li className='nav-item'>
            <a className='nav-link' href="/">Home</a>
          </li>
          <li className='nav-item'>
            <a className='nav-link' href="/login">Login</a>
          </li>
          <li className='nav-item'>
            <a className='nav-link' href="/register">Register</a>
          </li>
        </ul>
      ) : (
        <div className="logout-section">
          <button className="btn btn-danger" onClick={handleLogout}>
            Logout
          </button>

          <button onClick={() => navigate('/createquiz')} className="btn">
            Create Quiz
          </button>

        </div>
      )}
    </div>
  );
};

Pocetna.propTypes = {
  user: PropTypes.object,
  setUser: PropTypes.func.isRequired,
};

export default Pocetna;
