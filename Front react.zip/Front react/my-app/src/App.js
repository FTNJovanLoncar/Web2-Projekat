import './App.css';
import { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Pocetna from './Pocetna';
import Login from './Login';
import Createquiz from './Createquiz';
import Register from './Register';

function App() {
  const [user, setUser] = useState(null); // store logged-in user info or token

  const handleRegister = (userData) => {
    setUser(userData); // save user info or JWT
  };

  return (
    <div>
      <BrowserRouter>
        <Routes>        
          <Route path="/" element={<Pocetna user={user} setUser={setUser} />} />
          <Route path="/login" element={<Login onLogin={setUser}/>} />
          <Route path="/register" element={<Register onRegister={handleRegister} />} />
          <Route path="/createquiz" element={<Createquiz />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
