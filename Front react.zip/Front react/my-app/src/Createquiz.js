import { useState } from "react";
import "./Createquiz.css";

const Createquiz = () => {
  const [questions, setQuestions] = useState([]);

  const addQuestion = (type) => {
    setQuestions([
      ...questions,
      { type, text: "", options: ["", "", "", ""], correctAnswers: [] },
    ]);
  };

  const handleSubmit = async () => {
  try {
    const token = localStorage.getItem('token'); // Get the JWT from localStorage
    if (!token) {
      alert("You must be logged in to submit a quiz.");
      return;
    }

    const response = await fetch('https://localhost:7221/api/quizzes', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`, // Attach JWT for auth
      },
      body: JSON.stringify({ 
        title: "My Quiz",  // you can replace this with a dynamic input for quiz title
        questions: questions
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      alert("Failed to submit quiz: " + errText);
      return;
    }

    const result = await response.json();
    console.log("Quiz submitted successfully:", result);
    alert("Quiz submitted successfully!");
    setQuestions([]); // Clear the quiz builder if needed
  } catch (err) {
    console.error("Error submitting quiz:", err);
    alert(`An error occurred: ${err.message}`);
  }
};


  return (
    <div className="create-quiz-container">
      <h2>Create a Quiz</h2>

      {questions.map((q, index) => (
        <div key={index} className="question-block">
          <label>Question {index + 1}:</label>
          <input
            type="text"
            value={q.text}
            onChange={(e) => {
              const updated = [...questions];
              updated[index].text = e.target.value;
              setQuestions(updated);
            }}
            placeholder="Enter your question"
          />

          {q.type === 1 && (
            <div>
              {q.options.map((opt, i) => (
                <div key={i} className="option-input">
                  <input type="radio" name={`q${index}`} disabled />
                  <input
                    type="text"
                    value={opt}
                    onChange={(e) => {
                      const updated = [...questions];
                      updated[index].options[i] = e.target.value;
                      setQuestions(updated);
                    }}
                    placeholder={`Option ${i + 1}`}
                  />
                </div>
              ))}
            </div>
          )}

          {q.type === 2 && (
            <div>
              {q.options.map((opt, i) => (
                <div key={i} className="option-input">
                  <input type="checkbox" disabled />
                  <input
                    type="text"
                    value={opt}
                    onChange={(e) => {
                      const updated = [...questions];
                      updated[index].options[i] = e.target.value;
                      setQuestions(updated);
                    }}
                    placeholder={`Option ${i + 1}`}
                  />
                </div>
              ))}
            </div>
          )}

          {q.type === 3 && (
            <div>
              <div className="option-input">
                <input type="radio" name={`q${index}`} disabled />
                <input
                  type="text"
                  value={q.options[0]}
                  onChange={(e) => {
                    const updated = [...questions];
                    updated[index].options[0] = e.target.value;
                    setQuestions(updated);
                  }}
                  placeholder="Option 1"
                />
              </div>
              <div className="option-input">
                <input type="radio" name={`q${index}`} disabled />
                <input
                  type="text"
                  value={q.options[1]}
                  onChange={(e) => {
                    const updated = [...questions];
                    updated[index].options[1] = e.target.value;
                    setQuestions(updated);
                  }}
                  placeholder="Option 2"
                />
              </div>
            </div>
          )}

          {q.type === 4 && (
            <div>
              <label>Answer (Text):</label>
              <input type="text" placeholder="User will type the answer" disabled />
            </div>
          )}
        </div>
      ))}

      <button className="add-btn" onClick={() => addQuestion(1)}>
        Add Single Choice (4 options)
      </button>
      <button className="add-btn" onClick={() => addQuestion(2)}>
        Add Multiple Choice (4 options)
      </button>
      <button className="add-btn" onClick={() => addQuestion(3)}>
        Add Yes/No Question
      </button>
      <button className="add-btn" onClick={() => addQuestion(4)}>
        Add Text Question
      </button>

      <button className="submit-btn" onClick={handleSubmit}>
        Submit Quiz
      </button>
    </div>
  );
};

export default Createquiz;
